export interface ForgotPasswordResult {
  success: boolean;
  deliveryDetails: any;
}
