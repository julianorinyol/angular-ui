import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unsaved-changes',
  templateUrl: './unsaved-changes.component.html',
  styleUrls: ['./unsaved-changes.component.scss']
})
export class UnsavedChangesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
