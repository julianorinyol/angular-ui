export enum ResultScoreMode {
  'bar',
  'text',
}
