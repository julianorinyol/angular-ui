import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-dialog',
  templateUrl: './mobile-dialog.component.html',
  styleUrls: ['./mobile-dialog.component.scss']
})
export class MobileDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
