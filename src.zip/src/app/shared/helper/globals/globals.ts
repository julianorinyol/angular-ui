export class Globals {
  public static dialogData = {
    width: '30%'
  };
}
