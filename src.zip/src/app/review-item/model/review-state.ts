export enum ReviewState {
  open,
  in_progress,
  closed,
}
