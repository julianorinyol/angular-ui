export interface Option {
  id: string;
  text: string;
  value: number;
  tooltip: string;
}
