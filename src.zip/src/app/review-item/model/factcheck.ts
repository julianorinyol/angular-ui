export interface Factcheck {
    id: string;
    url: string;
    title: string;
  }
