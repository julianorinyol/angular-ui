export interface UserDeleteReason {
  reason: string;
  reasonText?: string;
}
