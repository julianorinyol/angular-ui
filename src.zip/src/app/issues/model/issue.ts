export interface Issue {
    id: string;
    category: string;
    message: string;
    item_id: string;
}
